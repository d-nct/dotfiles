#!/bin/bash

# Esse script apenas exibe o tempo de pomodoro. Não sei se é a forma mais leve...

POMODORO_STATUS=$(tmux display-message -p '#{pomodoro_status}')

if [ -n "$POMODORO_STATUS" ]; then
    echo " $POMODORO_STATUS"
else
    echo ""
fi
