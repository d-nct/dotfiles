#!/bin/bash
uptime -s | xargs -I {} date -d {} +%s | xargs -I {} bash -c 'echo $(( ( $(date +%s) - {} ) / 3600 ))'
